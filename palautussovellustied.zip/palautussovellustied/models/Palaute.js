var db = require('../lib/dbconn'); //reference of dbconnection.js 

var Task = { 
    getAllTasks: function(callback) { 
    return db.query("select * from palautetaulu", callback); 
  }, 
  getTaskById: function(id, callback) { 
    return db.query("select * from palautetaulu where palaute_id=?", [id], callback); 
  }, 
  addTask: function(Task, callback) { 
    return db.query("insert into palautetaulu values(?,?,?)", [Task.id, Task.title, Task.status], callback); 
  }, 
  deleteTask: function(id, callback) { 
    return db.query("delete from palautetaulu where palaute_id=?", [id], callback); 
  }, 
  updateTask: function(id, Task, callback) { 
    return db.query("update palautetaulu set otsikko=?,viesti=? where palaute_id=?", [Task.title, Task.status, id], callback); 
  } 
}; 
module.exports = Task;