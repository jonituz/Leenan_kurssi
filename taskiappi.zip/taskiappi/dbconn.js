var mysql        = require('mysql'); 

var connection   = mysql.createConnection({ 
  supportBigNumbers: true, 
  bigNumberStrings: true, 
  host     : "magnesium", 
  user     : "16ajonik", 
  password : "salasana", 
  database : "db16ajonik" 
}); 

module.exports = connection;